class LeaveType < ActiveRecord::Base
has_many :leave_applied_details
end
