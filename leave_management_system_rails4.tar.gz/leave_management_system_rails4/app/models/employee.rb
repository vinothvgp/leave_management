class Employee < ActiveRecord::Base
has_many :users
belongs_to :department
belongs_to :designation
#has_one :employee
has_many :leave_applied_details

validates :mob_number, :presence => true,:numericality =>true,:uniqueness => true,:length =>{:minimum=>10}
validates_format_of :mob_number, 
    length: { in: 10 },
    :with => /\A(\d{10}|\(?\d{3}\)?[-. ]\d{3}[-.]\d{4})\z/,
    :message => "Formato invalido"
validates :notice_period, :presence => true,:numericality =>true, :length =>{:minimum=>2}
validates :email, :presence => true, :uniqueness => true

end
