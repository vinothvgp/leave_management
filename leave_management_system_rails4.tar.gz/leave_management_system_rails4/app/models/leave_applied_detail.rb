class LeaveAppliedDetail < ActiveRecord::Base
belongs_to :leave_type
belongs_to :employee

validates :leave_type_id, :presence => true
validates :from_date, :presence => true

enum status: [:Approved, :Rejected]
end

