class Login < ActiveRecord::Base
end
