class Designation < ActiveRecord::Base
end
