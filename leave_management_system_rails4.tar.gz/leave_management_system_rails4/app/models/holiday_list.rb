class HolidayList < ActiveRecord::Base
end
