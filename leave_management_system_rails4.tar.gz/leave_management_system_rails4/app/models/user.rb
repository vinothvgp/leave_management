class User < ActiveRecord::Base
belongs_to :employee

#has_secure_password

#validates :name, :presence =>true, :uniqueness =>true, :length =>{:in =>3..10}
#validates :email, :confirmation=>true,:presence=>true,  :email=> true,:uniqueness=>true  #,format: {with: VALIDATE_EMAIL_ID}
#validates  :password, presence: true



#attr_accessor :password
 # EMAIL_REGEX = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i
#  validates :name, :presence => true, :uniqueness => true, :length => { :in => 3..20 }
#  validates :mail_id, :presence => true, :uniqueness => true, :format => EMAIL_REGEX
#  validates :password, :confirmation => true #password_confirmation attr
#validates_length_of :password, :in => 6..20, :on => :create

#before_save :encrypt_password
#after_save :clear_password
#attr_accessible :username, :email, :password, :password_confirmation
#def encrypt_password
 # if password.present?
 #   self.salt = BCrypt::Engine.generate_salt
 #   self.encrypted_password= BCrypt::Engine.hash_secret(password, salt)
 # end
#end
#def clear_password
#  self.password = nil
#end


  # Returns the hash digest of the given string.
#  def User.digest(string)
 #   cost = ActiveModel::SecurePassword.min_cost ? BCrypt::Engine::MIN_COST : BCrypt::Engine.cost
  #  BCrypt::Password.create(string, cost: cost)
#  end



end
