class LoginsController < ApplicationController
  def index
   session[:user_id] = nil
  end

  def create
   # sss
   # raise params.inspect
   user = User.find_by_name(params[:login][:user_name].downcase)
     #raise params[:login][:password].inspect
    if user && user.password == (params[:login][:password])#user.authenticate(params[:login][:password]) #
      session[:user_id] = user.id
      session[:user_name]=user.name
      redirect_to controller: "welcomes" 
    else
      session[:user_id] = nil
      session[:user_name] = nil
      render 'index'
      flash[:danger] = 'Invalid email/password combination' 
    end
  end
  def current_user
    @current_user ||= User.find_by(id: session[:user_id])
  end
  def destroy
    sdsd
   session[:user_id] = nil
    session[:user_name] = nil
   redirect_to action: "index",notice: "Logged Out!"
  end
 
 private
  def login_params
    params.require(:login).permit(:email,:password)
  end
end
