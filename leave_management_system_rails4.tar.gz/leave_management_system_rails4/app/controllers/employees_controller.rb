class EmployeesController < ApplicationController
require 'securerandom'
def index
  @employees = Employee.order('id').paginate(page: params[:page],per_page: 5)
  next_empcode =Employee.last.id
  next_empcode = "#{(Employee.last.id.to_i + 1).to_s}"
end
def new
@employee = Employee.new
end
def show
  @employee = Employee.find(params[:id])
end
def create
 # raise params[:employee][:emp_code].inspect
  @employee = Employee.find_by_emp_code(params[:employee][:emp_code])
    #raise @employee.inspect 
  if !@employee.blank?
    if @employee.update_attributes(employee_params)
   # raise @employee.inspect
    #if 
      redirect_to action: 'index', notice:"Employee Updated Successfully"
      #flash[:notice] = 
    else
      render action: "edit"
    end
        
  else
  @employee = Employee.new(employee_params)
  user = @employee.save
  @password = SecureRandom.hex(3)
  @user = User.new(user_params.to_h.merge(password: @password,employee_id: @employee.id))
  user = @user.save
   #if user.error
    #redirect_to action: 'new'
   #else
    redirect_to action: 'index'
    flash[:notice] = "Employee Create Successfully"
   #end
  end
 
end
def edit
  @employee = Employee.find(params[:id])
end

private
  def employee_params
    params.require(:employee).permit(:name,:emp_code,:mob_number,:email,:address,:date_of_birth,:emp_status,:date_of_joining,:department_id,:is_head,:is_admin,:manager_id,:designation_id,:notice_period)
  end
  def user_params
    params.require(:employee).permit(:name,:email)
  end
end

