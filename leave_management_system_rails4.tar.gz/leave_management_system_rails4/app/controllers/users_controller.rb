class UsersController < ApplicationController

def index
    @users = User.all.paginate(page: params[:page],per_page: 10)
    @employees = Employee.order('name ')
    #@login_detail = LoginDetail.new

end
def new
#@user = User.new
end
def create
#raise params[:user].inspect
 #@user = User.new(user_params) 

@password = SecureRandom.hex(3)
  @user = User.new(user_params)
#raise [@user,@password].inspect
  @user.save
#@user.password_confirmation = params[:user][:password]


# @user = User.new(params[:user])
# @article = Article.new(params.require(:article).permit(:title, :text))
#@user = User.new(params.require(:user).permit(:name, :text))
  if @user.save
    flash[:notice] = "User created successfully"
     redirect_to action: 'index'
#redirect_to(@login_detail, :notice => 'Login detail was successfully created.')
  else
    flash[:notice]="invalid"
     redirect_to action: 'index'
  end
end

 def show
    @user = User.find(params[:id])
 end
 def load_mail
  raise params.inspect
 end
private
  def user_params
    params.require(:user).permit(:name,:employee_id,:email,:password)
  end
end
