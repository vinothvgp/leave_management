class LeaveAppliedDetailsController < ApplicationController
 # http_basic_authenticate_with  except: [:index, :show]
def index
  @leave_applied_detail =LeaveAppliedDetail.all
   @employee = User.find(session[:user_id]).employee 
     if @employee.marital_status == 'Married' && @employee.gender == 'Male'
       @leave_types = LeaveType.where('(gender =? or gender=?) and (marital_status=? or marital_status=?)','Both','Male','Married','Both')
     elsif @employee.marital_status == 'Married' && @employee.gender == 'Female'
       @leave_types = LeaveType.where('(gender = ? or gender =?) and (marital_status=? or marital_status=?)','Both','Female','Married','Both')
     else
       @leave_types = LeaveType.where('gender =? and marital_status=?','Both','Both')
     end
end
def new

end
def create
   @apply_leave = LeaveAppliedDetail.new(leave_applied_detail_params.merge(manager_approval: 'Pending'))
   @apply_leave.save
   redirect_to action: 'index' 
   flash[:notice] ="Leave Applied Successfully"
end
def leave_status
   @employee = User.find(session[:user_id]).employee
   @leave_applied_detail =LeaveAppliedDetail.where('employee_id=? and leave_status is null',@employee.id)
end
def leave_approval
   @employee = User.find(session[:user_id]).employee 
   @leave_applied_detail =LeaveAppliedDetail.where('manager_approval=? and leave_status is null','Pending').paginate(page: params[:page],per_page: 10)
  
end
def save_leave_approval
  for lad in params[:manager_approval].keys
    
    @leave_app_detail =LeaveAppliedDetail.find(lad)
    @leave_app_detail.update_attributes(:manager_approval=>'Approved') if params[:manager_approval][lad] == 'Approved'
    @leave_app_detail.update_attributes(:manager_approval=>'Rejected') if params[:manager_approval][lad] == 'Rejected'
      
  end
     redirect_to action: 'leave_approval'
     flash[:notice] ="Leave Approved Successfully"
end
def employee_holiday
   @dec_holiday = HolidayList.where(:htype =>'dec')
   @opt_holiday = HolidayList.where(:htype=>'opt')
end
def leave_balance
  
  @employee = User.find(session[:user_id]).employee
  @leave_app_detail =LeaveAppliedDetail.where('employee_id =? and manager_approval =?',@employee.id,'Approved').select('leave_type_id,SUM(no_of_days) as leave_days_sum').group('leave_type_id')
 # @leave_applied_detail = LeaveAppliedDetail.where('employee_id =? and leave_type_id in (?)',@employee.id,@leave_app_detail)
  #raise  @leave_app_detail[1].leave_days_sum.inspect 
       if @employee.marital_status == 'Married' && @employee.gender == 'Male'
         @leave_types = LeaveType.where('(gender =? or gender=?) and (marital_status=? or marital_status=?)','Both','Male','Married','Both')
       elsif @employee.marital_status == 'Married' && @employee.gender == 'Female'
         @leave_types = LeaveType.where('(gender = ? or gender =?) and (marital_status=? or marital_status=?)','Both','Female','Married','Both')
       else
         @leave_types = LeaveType.where('gender =? and marital_status=?','Both','Both')
       end
end
def leave_cancel
  @employee = User.find(session[:user_id]).employee
  @leave_applied_detail =LeaveAppliedDetail.where('manager_approval=? and employee_id=? and leave_status !=?','Pending',@employee.id,'Cancelled')
end
def update_leave_cancellation
  #for lad in params[:status]
    @leave_applied_detail = LeaveAppliedDetail.find(params[:id])
    @leave_applied_detail.update_attributes(:leave_status=>'Cancelled') if @leave_applied_detail
  #end
       redirect_to action: 'leave_cancel'
       flash[:notice] ="Leave Cancelled"
end
private
 def leave_applied_detail_params
      params.require(:leave_applied_details).permit(:employee_id, :from_date, :to_date, :reason,:leave_type_id,:no_of_days)
  end
 #def lead_app_params
  #   params.require(:lad).permit(:lead_approval)
 #end
end
