class SessionsController < ApplicationController
    #authuser = User.auth(params[:name], params[:password])
   # if authuser
   #   session[:userid] = authuser.id
   #     flash[:notice] = "We logged you in, #{authuser.name}!"
  #  else
  #      flash[:notice] = "INVALID USERNAME/PASSWORD!"
  #  end
raise params.inspect
  end
