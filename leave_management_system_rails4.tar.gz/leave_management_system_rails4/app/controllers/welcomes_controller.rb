class WelcomesController < ApplicationController
  def index
@emp = User.find(session[:user_id]).employee
#raise @emp.inspect
  end
end
