module ApplicationHelper
  EmpStatus = {
    
  "gender" =>[
  ['Male','male'],
  ['Female','Female'],
  ['Other','Other']
  ],
    "marital_status" =>[
  ['Married','Married'],
  ['Unmarried','Unmarried']
  ]
  }
  #@emp =User.find_by_id(session[:user_id]).employee if session[:user_id]
  def emp(user)
    #raise user.inspect
    s = User.find(user).employee
    raise s.inspect
    
  end
  def get_gender(g)
    return EmpStatus[g]
  end
  def get_mstatus(gm)
    return EmpStatus[gm]
  end
end
