module UsersHelper

UserStatus = {

"status" =>[
['Active','Active'],
['InActive','InActive']
]
}
def get_status(estatus)
    return  UserStatus[estatus];
end
end
