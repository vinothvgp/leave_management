module EmployeesHelper
EmpStatus = {
"empl_status" =>[
['worker','worker'],
['employee','employee'],
['self-employed','self-employed'],
['contractor','contractor'],
['director','director']
],

"status" =>[
['Active','Active'],
['InActive','InActive']
]
}
def get_emp_status(estatus)
    return [["Select", "" ]]+ EmpStatus[estatus];
  end

def next_empcode
  next_empcode = "ABC-#{(Employee.last.id.to_i + 1).to_s}"
end
def emp(mid)
  #raise mid.inspect
  #Employee.find(mid)
end
end
