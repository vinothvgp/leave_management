module LeaveAppliedDetailsHelper

def emp_name_code
   Employee.all.map{ |c| ["#{c.name} - [#{c.emp_code}]", c.emp_code]}
end
def applied_leave(lad,lt)
  #lt.leave_applied_details.where('employee_id =?',emp).select('no_of_days').last
 for ll in lad
  #lad.where('leave_type_id =?',lt)
 end
end
end
