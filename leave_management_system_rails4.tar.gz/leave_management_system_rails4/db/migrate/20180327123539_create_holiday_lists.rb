class CreateHolidayLists < ActiveRecord::Migration
  def change
    create_table :holiday_lists do |t|
      t.string :occasion
      t.date :date
      t.string :day
      t.type :string
    end
  end
end
