class CreateLeaveAppliedDetails < ActiveRecord::Migration
  def change
    create_table :leave_applied_details do |t|
      t.integer :employee_id ,:null=>false
      t.integer :leave_type_id,:null=>false
      t.date :from_date,:null=>false
      t.date :to_date
      t.text :reason
      t.string :lead_approval
      t.string :manager_approval
      t.integer :no_of_days
      t.integer :leave_balance
      t.string :status
t.timestamps null: false
    end
  end
end
