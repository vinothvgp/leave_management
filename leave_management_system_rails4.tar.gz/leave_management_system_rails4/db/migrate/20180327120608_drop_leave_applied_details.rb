class DropLeaveAppliedDetails < ActiveRecord::Migration
  def change
drop_table :leave_applied_details
  end
end
