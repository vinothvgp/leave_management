# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20180327123539) do

  create_table "departments", force: :cascade do |t|
    t.string "name",   limit: 100
    t.string "status", limit: 10
  end

  create_table "designations", force: :cascade do |t|
    t.string "name",   limit: 100
    t.string "status", limit: 10
  end

  create_table "employees", force: :cascade do |t|
    t.string   "emp_code",        limit: 255
    t.string   "name",            limit: 255
    t.string   "email",           limit: 255
    t.text     "address"
    t.integer  "mob_number",      limit: 8
    t.string   "emp_status",      limit: 255, default: "Active"
    t.date     "date_of_joining"
    t.date     "resing_date"
    t.integer  "department_id"
    t.integer  "designation_id"
    t.integer  "salary"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "notice_period"
    t.string   "code",            limit: 255, default: "nextval('emp_codes'::regclass)"
    t.date     "date_of_birth"
    t.string   "personal_email",  limit: 50
  end

  create_table "holiday_lists", force: :cascade do |t|
    t.string "occasion"
    t.date   "date"
    t.string "day"
  end

  create_table "leave_applied_details", force: :cascade do |t|
    t.integer "employee_id"
    t.integer "leave_type_id"
    t.date    "from_date"
    t.date    "to_date"
    t.text    "reason"
    t.boolean "lead_approval"
    t.boolean "manager_approval"
    t.integer "no_og_days"
    t.integer "leave_balance"
  end

  create_table "leave_types", force: :cascade do |t|
    t.string   "name"
    t.string   "status"
    t.string   "gender"
    t.string   "marital_status"
    t.integer  "no_of_days"
    t.datetime "created_at",     null: false
    t.datetime "updated_at",     null: false
  end

  create_table "login_details", force: :cascade do |t|
    t.string  "user_name",  limit: 50,                                                              null: false
    t.string  "emp_code",   limit: 50,  default: "nextval('login_details_emp_code_seq'::regclass)", null: false
    t.string  "status",     limit: 20
    t.integer "mob_number", limit: 8,                                                               null: false
    t.string  "mail_id",    limit: 100
    t.string  "password",   limit: 50,                                                              null: false
    t.string  "password2",  limit: 50,                                                              null: false
    t.integer "emp_id"
  end

  create_table "users", force: :cascade do |t|
    t.string   "password",                   null: false
    t.integer  "employee_id",                null: false
    t.string   "email",                      null: false
    t.datetime "confirmed_at"
    t.datetime "created_at",                 null: false
    t.datetime "updated_at",                 null: false
    t.string   "name",            limit: 50
    t.string   "password_digest"
  end

end
