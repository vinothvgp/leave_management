require 'test_helper'

class LeaveAppliedDetailTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
