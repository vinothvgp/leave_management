require 'test_helper'

class EmployeesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
